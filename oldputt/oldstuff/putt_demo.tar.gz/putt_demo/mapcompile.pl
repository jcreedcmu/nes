#!/usr/bin/perl


while (<>) {
  for (split) {
    if (/[1-9]/) {
      print chr(32 + $_);
    }
    if (/[a-g]/) {
      print chr(32 + 10 + ord() - ord("a"));
    }
    if (/\./) {
      print chr(32);
    }
  }
}
